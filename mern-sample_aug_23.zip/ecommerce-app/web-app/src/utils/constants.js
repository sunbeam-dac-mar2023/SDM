export const constants = {
  serverUrl: 'http://3.110.169.244:4000',
}
