module.exports = {
  email: {
    user: '',
    password: '',
  },
  secret: 'quTXLpXykh',
}
