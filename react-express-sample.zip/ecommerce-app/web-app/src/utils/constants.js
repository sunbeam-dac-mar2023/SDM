export const constants = {
  serverUrl: 'http://localhost:4000',
}
