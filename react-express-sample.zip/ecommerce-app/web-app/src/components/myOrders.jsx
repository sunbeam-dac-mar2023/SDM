function MyOrders() {
  return (
    <div>
      <h1>My Orders</h1>
    </div>
  )
}

export default MyOrders
